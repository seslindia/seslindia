import { useState } from 'react';
import Person from './Person';

function App() {
  const [player, setPlayer] = useState(null);
  const users = [
    {
      name:"Kuldeep",
      gender:"M"
    },
    {
      name:"Shekhar",
      gender:"M"
    },
    {
      name:"Pooja",
      gender:"F"
    },
    {
      name:"Sunder",
      gender:"F"
    },
  ]

  const playerHandler = (name) => {
    setPlayer(name);
  }

  return (
    <div className='container'>
      <h1 className="text-center my-4">
        {player} is playing
      </h1>
      <div className="row py-4">
        {
          users.map(
            (u, i) => {
              return <Person player={player} handler={playerHandler} name={u.name} gender={u.gender} key={i} />
            }
          )
        }
      </div>
    </div>
  );
}

export default App;
