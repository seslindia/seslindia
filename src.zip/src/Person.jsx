import React from 'react'

export default function Person(props) {
  return (
    <div className='col-3'>
        <div className="shadow py-2">
      <h4>Name: {props.name}</h4>
      <h4>Gender: {props.gender}</h4>
      <button onClick={() => props.handler(props.name)} className={`btn ${props.player == props.name ? 'btn-warning' : 'btn-primary'}`}>
        {
            props.player == props.name ? 'Playing' : 'Play'
        }
      </button>
        </div>
    </div>
  )
}
